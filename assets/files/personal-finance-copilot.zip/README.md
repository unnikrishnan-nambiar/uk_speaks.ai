# Personal Finance Copilot v2.0.0

India-smart, globally adaptable educational finance plugin for ChatGPT.

## What's included
- Private-by-default onboarding
- Cash flow and expense reconciliation
- Budget, emergency funds, annual-cost buffers
- Debt-vs-invest decision analysis
- Insurance coverage checklists
- Goal-based investing educational frameworks
- Big purchase due diligence
- Monthly financial health review
- Source-backed India finance reasoning

## Install
This ZIP is a **plugin source archive**, not a standalone application or guaranteed one-click install. If your ChatGPT workspace supports plugin import/creation, use its provided workflow to install. Publishing or sharing a source ZIP does not automatically install it for others. Individual users must have their own compatible access.

## First prompt
'I'm in India. Help me build a financial health snapshot. Ask only for essential numbers; don't request bank credentials.'

## Privacy / limitations
No bank connection or persistent database is bundled. No automatic data collection, monitoring, payments, investment orders, personalized regulated investment advice, tax filing, or insurer/broker authorization. Do not upload full account identifiers, OTPs, PINs or confidential credentials. Replace personal information with redacted transactions.

## Attribution
This product is an original synthesis of publicly available personal-finance educational concepts. It is NOT affiliated with, endorsed by, or impersonating the Indian educators mentioned in `skills/india-finance-brain/references.md`.
