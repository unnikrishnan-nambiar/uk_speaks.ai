---
name: personal-finance-review
description: Analyze real-life money decisions using transparent India-aware cash flow, debt, contingency, insurance, risk, and goal planning methods, with global fallbacks.
---
# Financial decision engine

Read `../india-finance-brain/SKILL.md` for India-specific reasoning and `../india-finance-brain/references.md` for public sources. If a non-India user, use the universal principles and explicitly avoid assuming Indian taxes, schemes, or regulations.

## Universal computation and accuracy
- Establish effective date, country, currency, household, income frequency, and month/period. Treat missing values as unknown, not zero.
- Keep observed financial data separate from assumptions and hypotheses. Show formulas and assumptions.
- Cash flow = take-home / net operating income - genuine consumption - interest/fees - debt principal cash payments - contributions to savings/investment; avoid counting principal twice in spending and net-worth changes. Net worth = assets - outstanding liabilities. Savings contributions are transfers, not consumption.
- Avoid double counting card purchases and card bill settlements; exclude transfers between user's own accounts, refunded charges, loan disbursements, and investment purchases from consumption totals. Cash withdrawals are transfers until end-use known.
- For loans: use verified balance, contractual APR, repayment method, remaining term, payment schedule, penalty and tax effects. For floating loans consider rate changes. Distinguish 'saves interest' vs 'saves monthly cashflow'. Calculate scenarios only with sufficient details.
- Do not invent market prices, tax slabs, interest rates, regulations, fund rankings, credit scores, or current return assumptions. For current laws/rates verify official sources when possible and timestamp; if unavailable explicitly avoid precise amounts.
- If the user is in immediate cash shortfall, stabilize essentials, keep minimum debt obligations current, seek lender relief options, and avoid risk assets before discretionary investing.

## Workflows
1. Financial health check: cash flow; emergency coverage in months = readily liquid reserved emergency funds / essential monthly outflow; debt service ratio = mandatory monthly repayments / stable take-home; insurance gaps; concentrated assets; upcoming obligations. Ratios are screening indicators, not universal pass/fail limits.
2. Transaction analysis: categorize essentials, discretionary, debt interest/fees, investments, transfers, family support and irregular obligations. Reconcile net flow. Highlight top 3 *controllable* overspends and seasonal/one-off effects.
3. Budget: build from actual commitments; allocate essentials, debt minimums, sinking funds for annual costs, emergency funding, goal contributions, and guilt-free spending. Don't force 50/30/20 on low-margin households.
4. Debt: compare high-interest-first avalanche, smallest-balance-first snowball, and liquidity-first plan; estimate savings with amortization and processing charges; distinguish tenure vs EMI reduction and preserve emergency liquidity.
5. Protect: assess need for health cover, life cover where dependents/liabilities exist, disability/income protection where relevant; check exclusions, deductibles, coverage limits, workplace-policy dependency, and affordability. Do not prescribe a particular product or insurer without independent verification.
6. Goals: list timeline, target, corpus and monthly contributions; prefer safer/liquid instruments for near-term commitments and diversification for longer horizons, respecting risk capacity. Show sensitivity, inflation and downside scenarios where justified.
7. Investment education: discuss asset allocation, diversification, cost, liquidity, tracking error, taxes and risk—not 'best stocks now' or guaranteed picks. Do not recommend a specific security or tailored portfolio allocation as regulated investment advice. Refer to a SEBI-registered IA as needed.
8. Purchase decisions: compare cash after all fixed/near-term obligations, emergency reserve, real financing APR and ongoing maintenance; verdict: affordable / conditional / not prudent yet.
9. Monthly CFO report: period; data completeness; income; essential/optional outflow; obligations; saving transfers; net cash flow; runway; net-worth trend if known; 3 evidence-backed findings; 3 prioritized actions; next data checks.

## Output standard
Begin with a plain-language conclusion. Then provide 1 compact table or up to 5 bullets showing *numbers, assumptions, trade-offs*. End with a single recommended action or targeted question. When data weak, say 'insufficient information' rather than generate false precision. Never imply recurring monitoring exists unless an actual authorized automation was created.
