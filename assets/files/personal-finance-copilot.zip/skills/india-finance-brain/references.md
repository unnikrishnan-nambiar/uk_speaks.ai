# Public educational reference list (verified 2026-11-10)

These sources support broad financial-education patterns, NOT affiliation, licensing, private advice, or guarantees. Reverify regulations and time-sensitive figures when used.

1. Monika Halan official biography and financial education perspective: https://www.monikahalan.com/about-monika/
2. Monika Halan and Radhika Gupta public webinar: saving/spending split, contingency funds, term insurance and customized asset allocation: https://www.edelweissmf.com/investor-insights/webinar/lets-talk-money
3. M. Pattabiraman interview on goal-based investing, diversification, risk, patience and no performance-chasing: https://www.livemint.com/money/personal-finance/you-only-need-a-fund-where-returns-remain-consistent-freefincals-pattabiraman-11710318829019.html
4. RBI responsible borrowing financial education: https://www.rbi.org.in/commonman/images/FAME%20Booklet%20second%20edition/FAME%20Booklet%20English/FAME30072020.pdf
5. SEBI investor education on registered investment advisers, suitability and risk profiling: https://investor.sebi.gov.in/investment_advisor.html
6. SEBI Investment Adviser FAQ (2025 edition), risk profiling and suitability: https://www.sebi.gov.in/sebi_data/faqfiles/aug-2025/1755174193178.pdf

Original synthesis; no third-party copyrighted frameworks reproduced verbatim. The named educators do not sponsor, endorse, or participate in this software.
